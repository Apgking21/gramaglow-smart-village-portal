# GramaGlow 1.2 improvement summary

This release builds on the supplied GramaGlow 1.1 ZIP and the Attempt #4 evaluation report (89/100, Grade A).

## Report-driven improvements delivered

1. **Authentication hardening:** admin accounts are stored in SQLite with per-user usernames and salted `scrypt` password hashes. Password verification uses constant-time comparison. The environment variables provision/update the configured admin account at server startup. This replaces plaintext comparison against a single global password.
2. **Separation of concerns:** authentication is separated into `src/services/authService.js` and `src/repositories/adminUserRepository.js`; the repository owns persistence and password verification.
3. **Global request error boundary:** unexpected errors in the HTTP request handler are logged and converted into a safe JSON response rather than exposing stack traces to clients.
4. **Structured observability:** `src/observability/logger.js` emits timestamped JSON events for server startup, successful/failed sign-in and unexpected request/database errors.
5. **Operational health check:** `GET /api/health` verifies the process can query SQLite and reports a simple readiness state.
6. **Regression coverage:** the test runner now includes dedicated security tests for salted hashes, username lookup and invalid credentials, plus an API health check.

## Existing capabilities retained

Bilingual English/Hindi interface, light/dark/high-contrast modes, font scaling, audio notices, village profile, ward directory, development budgets, grievance filing and tracking, SLA escalation, government schemes, community voting, village asset map, static showcase and SQLite seed data.

## Honest architecture note

The supplied frontend is a vanilla JavaScript single-page application using a custom reactive store and hash router. It is not a React application and does not use actual React hooks. The report recommends a component-based frontend migration and moving all domain SQL into a Data Access Layer. This release separates authentication persistence and logic, but the existing domain API routes still contain some direct SQL queries; a complete repository/service migration remains future work. The frontend is also not yet migrated to React; that is a separate, larger frontend task.

## Password configuration

Set `GRAMAGLOW_ADMIN_USERNAME` and `GRAMAGLOW_ADMIN_PASSWORD` in the server environment before startup. The default username is `admin`; the password is required. Do not commit real credentials or share the `.env` file. The example uses Node.js built-in `scrypt` for salted password hashing, avoiding an additional native dependency. This meets the salted-hash objective, but it is not bcrypt; bcrypt/bcryptjs can be adopted if the deployment specifically requires bcrypt compatibility.

## Run and verify

- Node.js **22.5+** is required for the built-in `node:sqlite` API.
- `npm test` runs database, security and HTTP integration tests.
- `npm start` starts the portal.
- `GET /api/health` checks API/database readiness.
